var ruta_tapas = 'img/discos/';
var ruta_miniaturas = 'img/discos/mini/';
var boton_cierre_img = 'img/iconos/close.gif';
var boton_remover_img = 'img/iconos/Icon_Delete.png';
var boton_actualizar_img = 'img/iconos/actualizar_01.gif';
var boton_echo_img = 'img/iconos/Done.gif';
var boton_agregar1_img = 'img/iconos/boton_agregar.gif';
var boton_agregar2_img = 'img/iconos/boton_agregado2.gif';
var boton_atras_img = 'img/iconos/Arrow-Left.gif';
var boton_adelante_img = 'img/iconos/arrows.png';
var validacion_status = true;
var discos = [];	
discos = [
				{titulo:'America Solar Borde', imagen:'America_Solar_Borde.jpg', descrip:'', precio:25.4, cantidad: 1, estado: 0, oferta:true},
				{titulo:'Animal de Costumbre Contraste Borde', imagen:'Arquitectura_Tango_Borde.jpg', descrip:'', precio: 30, cantidad: 1, estado: 0, oferta:false},
				{titulo:'BrazilTango ReEdition Borde', imagen:'BrazilTango_ReEdition_Borde.jpg', descrip:'', precio: 23, cantidad: 1, estado: 0, oferta:false},
				{titulo:'Cantos Secretos Borde', imagen:'Cantos_Secretos_Borde.jpg', descrip:'', precio:25 , cantidad: 1, estado: 0, oferta:false},
				{titulo:'Capoeira Contraste Borde', imagen:'Capoeira_Contraste_Borde.jpg', descrip:'', precio:25, cantidad: 1, estado: 0, oferta:false},
				{titulo:'Coleccionismo Borde', imagen:'Coleccionismo_Borde.jpg', descrip:'', precio:25, cantidad: 1, estado: 0, oferta:false},
				
				{titulo:'Copabacana Borde', imagen:'Copabacana_Borde.jpg', descrip:'', precio:25, cantidad: 1, estado: 0, oferta:false},
				{titulo:'Electronico ReEdition Borde', imagen:'Electronico_ReEdition_Borde.jpg', descrip:'', precio:25, cantidad: 1, estado: 0, oferta:true},
				{titulo:'Guitarristas de Buenos_Aires Contraste_Borde', imagen:'Guitarristas_de_Buenos_Aires_Contraste_Borde.jpg', descrip:'', precio:25, cantidad: 1, estado: 0, oferta:false},
				{titulo:'Hora del Eclipse Contraste Borde Black', imagen:'Hora_del_Eclipse_Contraste_Borde_Black.jpg', descrip:'', precio:25, cantidad: 1, estado: 0, oferta:false},
				{titulo:'Mi Buenos Aires Herido New Borde', imagen:'Mi_Buenos_Aires_Herido_New_Borde.jpg', descrip:'', precio:25, cantidad: 1, estado: 0, oferta:false},
				{titulo:'Nuevo Giro Contraste Borde', imagen:'Nuevo_Giro_Contraste_Borde.jpg', descrip:'', precio:25, cantidad: 1, estado: 0, oferta:false},
				
				{titulo:'Psicodelia Tango Borde', imagen:'Psicodelia_Tango_Borde.jpg', descrip:'', precio:25, cantidad: 1, estado: 0, oferta:false},
				{titulo:'Secretos de la Guitarra Borde', imagen:'Secretos_de_la_Guitarra_Borde.jpg', descrip:'', precio:25, cantidad: 1, estado: 0, oferta:false},
				{titulo:'Tango Prodigo Contraste Borde', imagen:'Tango_Prodigo_Contraste_Borde.jpg', descrip:'', precio:25, cantidad: 1, estado: 0, oferta:true},
				{titulo:'The Grey Man Borde', imagen:'The_Grey_Man_Borde.jpg', descrip:'', precio:25, cantidad: 1, estado: 0, oferta:false}
];